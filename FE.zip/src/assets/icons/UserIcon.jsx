// User icon component
export const UserIcon = ({ className = '' }) => (
  <svg 
    width="16" 
    height="16" 
    viewBox="0 0 16 16" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <path 
      d="M3.69397 13.3332C3.69397 11.9275 4.80306 10.1772 7.99983 10.1772C11.196 10.1772 12.305 11.9148 12.305 13.3212" 
      stroke="#7A7A7A" 
      strokeWidth="1.5" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    />
    <path 
      fillRule="evenodd" 
      clipRule="evenodd" 
      d="M10.7502 5.41744C10.7502 6.93653 9.51891 8.16786 7.99978 8.16786C6.48131 8.16786 5.24997 6.93653 5.24997 5.41744C5.24997 3.89833 6.48131 2.66699 7.99978 2.66699C9.51891 2.66699 10.7502 3.89833 10.7502 5.41744Z" 
      stroke="#7A7A7A" 
      strokeWidth="1.5" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    />
  </svg>
);
